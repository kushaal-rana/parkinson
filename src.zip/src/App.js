import "./App.css";
import Charts from "./components/Charts";

function App() {
  return (
    <>
      <Charts />
    </>
  );
}

export default App;
